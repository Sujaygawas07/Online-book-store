<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>Quick Links</h3>
         <a href="home.php">Home</a>
         <a href="about.php">About</a>
         <a href="shop.php">Shop</a>
         <a href="contact.php">Contact</a>
      </div>

      <div class="box">
         <h3>Extra Links</h3>
         <a href="login.php">Login</a>
         <a href="register.php">Register</a>
         <a href="cart.php">Cart</a>
         <a href="orders.php">Orders</a>
      </div>

      <div class="box">
         <h3>Contact Info</h3>
         <p> <i class="fas fa-phone"></i> +91 7415766694 </p>
         <p> <i class="fas fa-phone"></i> +91 9552837190 </p>
         <p> <i class="fas fa-envelope"></i> readersgold11@gmail.com </p>
         <p> <i class="fas fa-map-marker-alt"></i> Lonavala, Maharashtra, Bharat (410401)</p>
      </div>

      <div class="box">
         <h3>Follow Us</h3>
         <a href="https://www.facebook.com/sujay.gawas.507/"> <i class="fab fa-facebook-f"></i> Facebook </a>
         <a href="https://www.instagram.com/pratik.1612/"> <i class="fab fa-instagram"></i> Instagram </a>
         <a href="https://www.linkedin.com/in/gourav-upadhayay-9a2128211/"> <i class="fab fa-linkedin"></i> Linkedin </a>
         <a href="#"> <i class="fab fa-twitter"></i> Twitter </a>
      </div>

   </div>

   <p class="credit"> &copy; copyright by <span>Reader's Gold</span> </p>

</section>